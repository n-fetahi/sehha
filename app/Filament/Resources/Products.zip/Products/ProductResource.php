<?php

namespace App\Filament\Resources\Products;

use App\Filament\Resources\Products\Pages;
use App\Models\Product;
use BackedEnum;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Actions\ViewAction;
use Filament\Forms;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Enums\FontWeight;
use Filament\Support\Icons\Heroicon;
use Filament\Tables;
use Filament\Tables\Columns\Layout\Stack;
use Filament\Tables\Table;

class ProductResource extends Resource
{
    protected static ?string $model = Product::class;

    // أيقونة القائمة
    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedShoppingBag;

    protected static ?string $recordTitleAttribute = 'name';

    public static function getNavigationGroup(): string|BackedEnum|null
    {
        return 'إدارة المحتوى';
    }

    protected static ?string $navigationLabel = 'المنتجات';
    protected static ?string $modelLabel = 'منتج';
    protected static ?string $pluralModelLabel = 'المنتجات';

    // ===== الفورم (إضافة / تعديل) =====
    public static function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('بيانات المنتج')
                    ->description('إدارة معلومات المنتج وصورته.')
                    ->schema([
                        Forms\Components\TextInput::make('name')
                            ->label('اسم المنتج')
                            ->required()
                            ->maxLength(255)
                            ->autocomplete(false),

                        Forms\Components\FileUpload::make('image')
                            ->label('صورة المنتج')
                            ->image()
                            ->directory('products') // storage/app/public/products
                            ->disk('public')
                            ->imagePreviewHeight('200')
                            ->openable()
                            ->downloadable(),

                        Forms\Components\Textarea::make('description')
                            ->label('وصف المنتج')
                            ->rows(4),
                    ])
                    ->columns(1),
            ]);
    }

    // ===== جدول / صفحة عرض المنتجات =====
    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                // تصميم يشبه الكروت Card لكل منتج
                Stack::make([
                    Tables\Columns\ImageColumn::make('image')
                        ->label(' ')
                        ->disk('public')
                        ->height(180),

                    Tables\Columns\TextColumn::make('name')
                        ->label('اسم المنتج')
                        ->weight(FontWeight::Bold)
                        ->searchable()
                        ->sortable(),

                    Tables\Columns\TextColumn::make('description')
                        ->label('الوصف')
                        ->limit(80),

                    Tables\Columns\TextColumn::make('created_at')
                        ->label('تاريخ الإضافة')
                        ->dateTime('Y-m-d H:i')
                        ->badge(),
                ])->space(2),
            ])
            // جعل الجدول شبكة (Grid) كروت:
            ->contentGrid([
                'md' => 2,  // شاشتين في الصف من حجم md
                'xl' => 3,  // ثلاث كروت في الصف من حجم xl
            ])
            ->filters([
                //
            ])
            ->actions([
                // زر عرض في نافذة منبثقة
                ViewAction::make()
                    ->label('عرض')
                    ->icon('heroicon-m-eye')
                    ->modalHeading('تفاصيل المنتج')
                    ->schema([
                        Forms\Components\FileUpload::make('image')
                            ->label('صورة المنتج')
                            ->image()
                            ->directory('products')
                            ->disk('public')
                            ->imagePreviewHeight('200')
                            ->disabled(),

                        Forms\Components\TextInput::make('name')
                            ->label('اسم المنتج')
                            ->disabled(),

                        Forms\Components\Textarea::make('description')
                            ->label('وصف المنتج')
                            ->rows(4)
                            ->disabled(),
                    ]),

                EditAction::make()
                    ->label('تعديل'),

                DeleteAction::make()
                    ->label('حذف'),
            ])
            ->bulkActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make()
                        ->label('حذف المحدد'),
                ]),
            ])
            ->defaultSort('id', 'desc')
            ->paginated([10, 25, 50]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListProducts::route('/'),
            'create' => Pages\CreateProduct::route('/create'),
            'edit' => Pages\EditProduct::route('/{record}/edit'),
        ];
    }
}
