<?php

namespace App\Http\Controllers\Api\Global;

use App\Http\Controllers\Concerns\FormatsTime;
use App\Http\Controllers\Controller;
use App\Models\Clinic;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use App\Models\ClinicAppointment; // تأكد من وجود هذا الموديل
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;


class ClinicController extends Controller
{
    use FormatsTime;

    public function show($clinic_id)
    {
        $clinic = Clinic::with(['user', 'schedule.weekdays'])
            ->where('id', $clinic_id)
            ->first();

        if (!$clinic) {
            return response()->json([
                'status' => 400,
                'message' => 'العيادة المطلوبة غير موجودة',
            ]);
        }

        // استخراج أيام العمل
        $workingDays = [];
        if ($clinic->schedule) {
            $workingDays = $clinic->schedule->weekdays->pluck('id')->toArray();
        }

        $data = [
            'id'                  => $clinic->id,
            'name'                => $clinic->name,
            'phone'               => $clinic->phone,
            'location'            => $clinic->location,
            'profile_picture'     => $clinic->profile_picture,
            'user_name'           => $clinic->user->name ?? null,
            'rating'              => 3.5,
            'years_of_experience' => $clinic->years_of_experience,
            'bio'                 => $clinic->bio,
            'is_available'        => $clinic->schedule ? $clinic->schedule->is_available : false,
            'booking_fee'         => $clinic->schedule ? $clinic->schedule->booking_fee : "0",
            'working_days'        => $workingDays,
            'start_time'          => $clinic->schedule ? $this->formatTime($clinic->schedule->start_time) : null,
            'end_time'            => $clinic->schedule ? $this->formatTime($clinic->schedule->end_time) : null,
        ];

        return response()->json([
            'status' => 200,
            'data'    => $data,
        ]);
    }

public function getAvailableDates(Request $request, $clinic_id): JsonResponse
{
    $clinic = Clinic::with('schedule.weekdays')->find($clinic_id);
    if (!$clinic) {
        return response()->json(['status' => 400, 'message' => 'العيادة غير موجودة'], 400);
    }
    $schedule = $clinic->schedule;
    if (!$schedule || !$schedule->is_available) {
        return response()->json(['status' => 200, 'data' => []]);
    }

    $workingWeekdayIds = $schedule->weekdays->pluck('id')->toArray();
    if (empty($workingWeekdayIds)) {
        return response()->json(['status' => 200, 'data' => []]);
    }

    // تحويل أيام العمل
    $map = [1=>6,2=>0,3=>1,4=>2,5=>3,6=>4,7=>5];
    $carbonDays = array_values(array_intersect_key($map, array_flip($workingWeekdayIds)));
    if (empty($carbonDays)) {
        return response()->json(['status' => 200, 'data' => []]);
    }

    $now = Carbon::now(); // الوقت الحالي
    $todayDate = $now->toDateString();
    $endDate = $now->copy()->addDays(39)->startOfDay(); // 40 يوم شاملة اليوم

    // حساب وقت القطع (end_time - ساعتين) مع ربطه بتاريخ اليوم
    $endTime = Carbon::parse($schedule->end_time);
    $cutoffDateTime = Carbon::parse($todayDate . ' ' . $endTime->format('H:i'))->subHours(2);
    $cutoffTimeString = $cutoffDateTime->format('H:i'); // للمقارنة النصية الاحتياطية

    $availableDates = [];

    for ($i = 0; $i <= 39; $i++) {
        $date = $now->copy()->addDays($i)->startOfDay();
        $dateString = $date->toDateString();

        // شرط أن يكون اليوم من أيام العمل
        if (!in_array($date->dayOfWeek, $carbonDays)) {
            continue;
        }

        // إذا كان التاريخ هو اليوم الحالي
        if ($dateString === $todayDate) {
            // نحصل على الوقت الحالي بالساعة والدقيقة فقط
            $currentTime = $now->format('H:i');
            // نقارن: إذا كان الوقت الحالي < وقت القطع، نضيف اليوم، وإلا لا نضيف
            if ($currentTime < $cutoffTimeString) {
                $availableDates[] = $dateString;
            }
            // وإلا ن跳过 هذا اليوم
        } else {
            // الأيام الأخرى تضاف دائماً (ما دامت ضمن أيام العمل)
            $availableDates[] = $dateString;
        }
    }

    return response()->json([
        'status' => 200,
        'data' => $availableDates
    ]);
}


/**
 * GET /api/clinics/{clinic_id}/available-times?date=YYYY-MM-DD
 */

public function getAvailableTimes(Request $request, $clinic_id): JsonResponse
{
    // 1. التحقق من وجود معلمة date وتنسيقها يدوياً
    $dateString = $request->input('date');
    if (!$dateString) {
        return response()->json([
            'status' => 400,
            'message' => 'يرجى إرسال date بالتنسيق Y-m-d'
        ], 400);
    }

    // محاولة تحويل التاريخ إلى كائن Carbon
    try {
        $date = Carbon::createFromFormat('Y-m-d', $dateString);
        if (!$date || $date->format('Y-m-d') !== $dateString) {
            throw new \Exception('Invalid date');
        }
    } catch (\Exception $e) {
        return response()->json([
            'status' => 400,
            'message' => 'التاريخ غير صالح: يجب أن يكون بصيغة Y-m-d'
        ], 400);
    }

    // 2. جلب العيادة وعلاقتها
    $clinic = Clinic::with('schedule')->find($clinic_id);
    if (!$clinic) {
        return response()->json(['status' => 400, 'message' => 'العيادة غير موجودة'], 400);
    }

    $schedule = $clinic->schedule;
    if (!$schedule || !$schedule->is_available) {
        return response()->json(['status' => 200, 'data' => []]);
    }

    // 3. توليد الأوقات النظرية
    $start = Carbon::parse($schedule->start_time);
    $end = Carbon::parse($schedule->end_time);
    $duration = (int) $schedule->consultation_duration;

    $availableTimes = [];
    $current = clone $start;

    while ($current->copy()->addMinutes($duration)->lte($end)) {
        $timeString = $current->format('H:i');
        $availableTimes[$timeString] = $timeString;
        $current->addMinutes($duration);
    }

    if (empty($availableTimes)) {
        return response()->json(['status' => 200, 'data' => []]);
    }

    // 4. إذا كان التاريخ اليوم، نحذف الأوقات التي مضت
    if ($date->isToday()) {
        $now = Carbon::now();
        $currentTime = $now->format('H:i');
        foreach ($availableTimes as $key => $time) {
            if ($time < $currentTime) {
                unset($availableTimes[$key]);
            }
        }
    }

    // 5. استبعاد الأوقات المحجوزة من جدول clinic_appointments
    // تأكد من استبدال ClinicAppointment باسم الموديل الصحيح لديك
    $bookedTimes = DB::table('clinic_appointments')
        ->where('clinic_id', $clinic_id)
        ->whereDate('appointment_date', $date->toDateString())
        ->whereIn('status', ['pending', 'approved', 'completed'])
        ->pluck('appointment_time')
        ->map(fn($t) => Carbon::parse($t)->format('H:i'))
        ->toArray();

    // إزالة المحجوزات من القائمة
    $availableTimes = array_values(array_diff($availableTimes, $bookedTimes));

    return response()->json([
        'status' => 200,
        'data' => $availableTimes,
    ]);
}
}
