<?php

namespace App\Http\Controllers\Api\Global;

use App\Http\Controllers\Concerns\FormatsTime;
use App\Http\Controllers\Controller;
use App\Models\Clinic;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;

class ClinicController extends Controller
{
    use FormatsTime;

    public function show($clinic_id)
    {
        $clinic = Clinic::with(['user', 'schedule.weekdays'])
            ->where('id', $clinic_id)
            ->first();

        if (!$clinic) {
            return response()->json([
                'status' => 400,
                'message' => 'العيادة المطلوبة غير موجودة',
            ]);
        }

        // استخراج أيام العمل
        $workingDays = [];
        if ($clinic->schedule) {
            $workingDays = $clinic->schedule->weekdays->pluck('id')->toArray();
        }

        $data = [
            'id'                  => $clinic->id,
            'name'                => $clinic->name,
            'phone'               => $clinic->phone,
            'location'            => $clinic->location,
            'profile_picture'     => $clinic->profile_picture,
            'user_name'           => $clinic->user->name ?? null,
            'rating'              => 3.5,
            'years_of_experience' => $clinic->years_of_experience,
            'bio'                 => $clinic->bio,
            'is_available'        => $clinic->schedule ? $clinic->schedule->is_available : false,
            'booking_fee'         => $clinic->schedule ? $clinic->schedule->booking_fee : "0",
            'working_days'        => $workingDays,
            'start_time'          => $clinic->schedule ? $this->formatTime($clinic->schedule->start_time) : null,
            'end_time'            => $clinic->schedule ? $this->formatTime($clinic->schedule->end_time) : null,
        ];

        return response()->json([
            'status' => 200,
            'data'    => $data,
        ]);
    }

    /**
 * GET /api/clinics/{clinic_id}/available-dates
 * إرجاع التواريخ المتاحة للحجز خلال 40 يومًا قادمة (من اليوم الحالي)
 */
public function getAvailableDates( $clinic_id)
{
    $clinic = Clinic::with('schedule.weekdays')->find($clinic_id);

    if (!$clinic) {
        return response()->json([
            'status' => 400,
            'message' => 'العيادة غير موجودة'
        ], 400);
    }

    $schedule = $clinic->schedule;

    // إذا لم يوجد جدول أو العيادة غير متاحة للحجز
    if (!$schedule || !$schedule->is_available) {
        return response()->json([
            'status' => 200,
            'data' => []
        ]);
    }

    // جلب أيام الأسبوع التي تعمل فيها العيادة (أرقام ids من جدول weekdays)
    $workingWeekdayIds = $schedule->weekdays->pluck('id')->toArray();

    if (empty($workingWeekdayIds)) {
        return response()->json([
            'status' => 200,
            'data' => []
        ]);
    }

    // تحويل weekday ids إلى نظام Carbon (0 = الأحد، 1 = الاثنين، ...، 6 = السبت)
    // نفترض أن جدول weekdays يحتوي على id = 1 للأحد، 2 للاثنين، ...، 7 للسبت
    $carbonDays = array_map(function ($id) {
        return $id - 1;
    }, $workingWeekdayIds);

    $startDate = Carbon::today();
    $endDate = $startDate->copy()->addDays(39); // 40 يوم شاملة اليوم

    $availableDates = [];
    $current = $startDate->copy();

    while ($current <= $endDate) {
        if (in_array($current->dayOfWeek, $carbonDays)) {
            $availableDates[] = $current->toDateString();
        }
        $current->addDay();
    }

    return response()->json([
        'status' => 200,
        'data' => $availableDates
    ]);
}
}
