<?php

namespace App\Http\Controllers\Api\Clinics;

use App\Http\Controllers\Concerns\FormatsTime;
use App\Http\Controllers\Controller;
use App\Models\ClinicSchedule;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ClinicScheduleController extends Controller
{
    use FormatsTime;
    /**
     * GET /api/clinics/schedule
     * إرجاع إعدادات الحجز الحالية للعيادة التابعة للمستخدم الحالي
     */
    public function show(Request $request): JsonResponse
    {
        $user = $request->user();



        $clinic = $user->ownedClinic; // العلاقة موجودة في User model

        if (!$clinic) {
            return response()->json([
                'status' => 400,
                'message' => 'لا توجد عيادة مرتبطة بهذا المستخدم'
            ], 400);
        }

        $schedule = $clinic->schedule()->with('weekdays:id,name')->first();

        if (!$schedule) {
            return response()->json([
                'status' => 200,
                'data' => null
            ], 200);
        }

        return response()->json([
            'status' => 200,
            'data' => [
                'id' => $schedule->id,
                'start_time' => $this->formatTime($schedule->start_time),
                'end_time' => $this->formatTime($schedule->end_time),
                'consultation_duration' => $schedule->consultation_duration,
                'follow_up_duration' => $schedule->follow_up_duration,
                'follow_up_period' => $schedule->follow_up_period,
                'booking_fee' => $this->normalizeFee($schedule->booking_fee),
                'is_available' => (bool) $schedule->is_available,
                'weekdays' => $schedule->weekdays->map(function ($day) {
                    return [
                        'id' => $day->id,
                        'name' => $day->name,
                    ];
                })->values(),
            ]
        ], 200);
    }

    /**
     * POST /api/clinics/schedule
     * إنشاء أو تحديث إعدادات الحجز للعيادة
     */
    public function store(Request $request): JsonResponse
    {
        $user = $request->user();

        $clinic = $user->ownedClinic;

        if (!$clinic) {
            return response()->json([
                'status' => 400,
                'message' => 'لا توجد عيادة مرتبطة بهذا المستخدم'
            ], 400);
        }

        $validator = Validator::make($request->all(), [
            'start_time' => ['required', 'date_format:H:i'],
            'end_time' => ['required', 'date_format:H:i', 'after:start_time'],
            'consultation_duration' => ['required', 'integer', 'min:1'],
            'follow_up_duration' => ['required', 'integer', 'min:1'],
            'follow_up_period' => ['required', 'integer', 'min:1'],
            'booking_fee' => ['required', 'numeric', 'min:0'],
            'is_available' => ['required', 'boolean'],
            'weekday_ids' => ['required', 'array', 'min:1'],
            'weekday_ids.*' => ['integer', 'exists:weekdays,id'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'message' => 'البيانات المرسلة غير صالحة',
                'errors' => $validator->errors()
            ], 400);
        }

        DB::beginTransaction();

        try {
            $schedule = ClinicSchedule::updateOrCreate(
                ['clinic_id' => $clinic->id],
                [
                    'start_time' => $request->start_time,
                    'end_time' => $request->end_time,
                    'consultation_duration' => $request->consultation_duration,
                    'follow_up_duration' => $request->follow_up_duration,
                    'follow_up_period' => $request->follow_up_period,
                    'booking_fee' => $request->booking_fee,
                    'is_available' => $request->is_available,
                ]
            );

            // تحديث الأيام: يزيد/ينقص حسب المرسل
            $schedule->weekdays()->sync($request->weekday_ids);

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'تم حفظ إعدادات الحجز بنجاح'
            ], 200);
        } catch (\Throwable $e) {
            DB::rollBack();

            return response()->json([
                'status' => 500,
                'message' => 'حدث خطأ أثناء حفظ إعدادات الحجز'
            ], 500);
        }
    }



    private function normalizeFee($value)
    {
        if ($value === null) {
            return 0;
        }

        return strpos((string) $value, '.') !== false
            ? (float) $value
            : (int) $value;
    }
}
