<x-layout title="Home - Dhofar National for Coatings L.L.C.">

    {{-- 🔹 جزء الهيرو الخاص بالصفحة الرئيسية --}}
    <x-slot name="hero">
        <div class="container-xxl py-5 bg-primary hero-header mb-5">
            <div class="container my-5 py-5 px-lg-5">
                <div class="row g-5 py-5">
                    <div class="col-lg-6 text-center text-lg-start">
                        <h1 class="text-white mb-4 animated zoomIn">
                            Welcome to Dohfar National for Coatings L.L.C.
                        </h1>
                        <p class="text-white pb-3 animated zoomIn">
                            If we look around, we are probably surrounded by roofs. They may look different,
                            but they have one thing in common - they all need a paint job to bring them back to life.
                        </p>
                        <a href="{{ url('/contact') }}"
                           class="btn btn-outline-light py-sm-3 px-sm-5 rounded-pill animated slideInRight">
                            Contact Us
                        </a>
                    </div>
                    <div class="col-lg-6 text-center text-lg-start">
                        <img class="img-fluid" src="{{ asset('images/hero.png') }}" alt="">
                    </div>
                </div>
            </div>
        </div>
    </x-slot>

    {{-- 🔹 هنا تضع باقي محتوى الصفحة الرئيسية (Sections, خدمات، منتجات مميزة، الخ...) --}}
    {{-- مثال بسيط placeholder: --}}
    <div class="container px-lg-5">
        {{-- محتوى تجريبي --}}
        {{-- ضع هنا أقسام الخدمات / المميزات / … --}}
    </div>

</x-layout>
