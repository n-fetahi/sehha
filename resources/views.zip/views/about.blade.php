<x-layout title="About Us - Dhofar National for Coatings L.L.C.">

    {{-- 🔹 الهيرو الخاص بصفحة عنا --}}
    <x-slot name="hero">
        <div class="container-xxl py-5 bg-primary hero-header mb-5">
            <div class="container my-5 py-5 px-lg-5">
                <div class="row g-5 py-5">
                    <div class="col-12 text-center">
                        <h1 class="text-white animated zoomIn">About Us</h1>
                        <hr class="bg-white mx-auto mt-0" style="width: 90px;">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item">
                                    <a class="text-white" href="{{ url('/') }}">Home</a>
                                </li>
                                <li class="breadcrumb-item text-white active" aria-current="page">About</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </x-slot>

    {{-- 🔹 محتوى صفحة "عنا" تحت الهيرو --}}
    <div class="container px-lg-5 pb-5">
        {{-- ضع هنا نص التعريف بالشركة، صورة، قيم الشركة، إلخ --}}
        {{-- مثال بسيط: --}}
        <div class="row g-5 align-items-center">
            <div class="col-lg-6">
                <img src="{{ asset('images/about.jpg') }}" alt="" class="img-fluid rounded">
            </div>
            <div class="col-lg-6">
                <h2 class="mb-3">Who We Are</h2>
                <p class="mb-3">
                    {{-- نص تعريفي بسيط --}}
                    We are Dohfar National for Coatings L.L.C., specialized in roof and industrial coatings...
                </p>
            </div>
        </div>
    </div>

</x-layout>
 Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem voluptate dolorum iusto, facilis possimus adipisci inventore obcaecati delectus temporibus numquam, nisi quia voluptatum asperiores quisquam deleniti modi nam ratione totam? Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, voluptas! Officia incidunt nesciunt, excepturi enim nemo laboriosam quaerat deleniti ipsum ea quis molestias impedit, libero eligendi recusandae? Officia, aspernatur dolore!
