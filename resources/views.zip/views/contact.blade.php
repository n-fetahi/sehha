<x-layout title="Contact Us - Dhofar National for Coatings L.L.C.">

    <x-slot name="hero">
        <div class="container-xxl py-5 bg-primary hero-header mb-5">
            <div class="container my-5 py-5 px-lg-5">
                <div class="row g-5 py-5">
                    <div class="col-12 text-center">
                        <h1 class="text-white animated zoomIn">Contact Us</h1>
                        <hr class="bg-white mx-auto mt-0" style="width: 90px;">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item">
                                    <a class="text-white" href="{{ url('/') }}">Home</a>
                                </li>
                                <li class="breadcrumb-item text-white active" aria-current="page">Contact</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </x-slot>

    {{-- نموذج تواصل / خريطة / معلومات التواصل --}}
    <div class="container px-lg-5 pb-5">
        {{-- Contact form هنا --}}
    </div>

</x-layout>
