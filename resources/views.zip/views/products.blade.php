<x-layout title="Products - Dhofar National for Coatings L.L.C.">

    <x-slot name="hero">
        <div class="container-xxl py-5 bg-primary hero-header mb-5">
            <div class="container my-5 py-5 px-lg-5">
                <div class="row g-5 py-5">
                    <div class="col-12 text-center">
                        <h1 class="text-white animated zoomIn">Products</h1>
                        <hr class="bg-white mx-auto mt-0" style="width: 90px;">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item">
                                    <a class="text-white" href="{{ url('/') }}">Home</a>
                                </li>
                                <li class="breadcrumb-item breadcrumb-item-light text-white active" aria-current="page">Products</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </x-slot>

    {{-- قسم الكروت --}}
    <div class="demo">
        <h2 class="penName">Material Cards Stack</h2>

        <div class="mainCard">
            <div class="mainCardHeader"></div>

            <div class="mainCardContent">
                @forelse ($products as $product)
                    <div class="miniCard product-card"
                         data-bs-toggle="modal"
                         data-bs-target="#productModal-{{ $product->id }}">

                        <div class="product-card-image-wrapper">
                            <img src="{{ asset('storage/' . $product->image) }}"
                                 alt="{{ $product->name }}"
                                 class="product-card-image">
                        </div>

                        <div class="product-card-body">
                            <h3 class="product-card-title">
                                {{ $product->name }}
                            </h3>

                            <button type="button"
                                    class="product-card-btn"
                                    data-bs-toggle="modal"
                                    data-bs-target="#productModal-{{ $product->id }}">
                                عرض التفاصيل
                            </button>
                        </div>
                    </div>
                @empty
                    <p class="text-center text-muted py-5 mb-0 w-100">
                        لا توجد منتجات مضافة حتى الآن.
                    </p>
                @endforelse
            </div>
        </div>
    </div>

   {{-- نوافذ التفاصيل (المودالات) خارج الكروت لثبات أفضل --}}
@foreach ($products as $product)
    <div class="modal fade product-modal"
         id="productModal-{{ $product->id }}"
         tabindex="-1"
         aria-labelledby="productModalLabel-{{ $product->id }}"
         aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content product-modal-content">
                <button type="button"
                        class="btn-close product-modal-close"
                        data-bs-dismiss="modal"
                        aria-label="Close"></button>

                <div class="product-modal-body">
                    {{-- ✅ الصورة في الأعلى --}}
                    <div class="product-modal-image-wrapper">
                        <img src="{{ asset('storage/' . $product->image) }}"
                             alt="{{ $product->name }}"
                             class="product-modal-image">
                    </div>

                    {{-- ✅ بيانات المنتج في الأسفل --}}
                    <div class="product-modal-text">
                        <h3 class="product-modal-title mb-3">
                            {{ $product->name }}
                        </h3>

                        <p class="product-modal-description mb-0">
                            {{ $product->description ?? 'No description provided for this product.' }}
                        </p>
                    </div>
                </div>

                <div class="product-modal-footer">
                    <button type="button"
                            class="btn btn-outline-light btn-sm px-3"
                            data-bs-dismiss="modal">
                        إغلاق
                    </button>
                </div>
            </div>
        </div>
    </div>
@endforeach


    {{-- ترقيم الصفحات إن وجد --}}
    @if ($products instanceof \Illuminate\Pagination\AbstractPaginator)
        <div class="mt-4 d-flex justify-content-center">
            {{ $products->links() }}
        </div>
    @endif

</x-layout>


